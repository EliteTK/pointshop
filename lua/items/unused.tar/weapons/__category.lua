CATEGORY.Name = 'Weapons'
CATEGORY.Icon = 'bomb'
CATEGORY.Order = -1