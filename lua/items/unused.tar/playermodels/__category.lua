CATEGORY.Name = 'Player Models'
CATEGORY.Icon = 'user'
